#!/usr/bin/env python
#-*- coding:utf-8 -*-

import re

# 编译选项，忽略大小写，可以跨行(详细模式)
FLAG = re.I|re.X

# SQLI
# for eval(), exit(), rand() are for xss and code,
sqli_tools = re.compile(r"sqlmap|havij|pangolin", FLAG)
sqli_blind = re.compile(r"sleep\(|waitfor([\s+])+delay\b", FLAG)
sqli_mysql = re.compile(r"(?:information_schema\.|/\*.*?\*/|concat|group_concat|concat_ws|system_user|session_user|current_user|load_file|database|unhex|hex)\(|into([\s+])+(?:out|dump)file\b|@@\w{2,11}\b(?!=)|/\*.*?\*/",FLAG)
sqli_mssql = re.compile(r"(?:db_name|@@servername|db_owner\b|master\.dbo|sysobjects\b)|(?:\sexec\s+xp_(?:cmdshell|filelist|regenumkeys|execresultset|makecab|regread|loginconfig|regaddmultistring|availablemedia|ntsec|regdeletekey|regdeletevalue|regremovemultistring|enumdsn|dirtree|terminate_process|regenumvalues|regwrite))",FLAG)
sqli_access = re.compile(r"(?:msysobjects|msysaccess)",FLAG)
sqli_common = re.compile(r"\b\d{1,5}(?:<>|>|<|!=|>=|<=)\d{1,5}|['\"]=['\"]|\b(?:and|or)\b\s+.{1,8}=|select\b[^?&]+from\b|(?:group|order)\b.*[^?&]+\bby\b|exists.*\(|(?:ascii|count|char|floor|substring|length)\(|%'",FLAG)
#中括号和反斜杠那里不知道有错没。


#CODE
code_keyword = re.compile(r"<\?php|php\?>|safe_mode=|allow_url_include=", FLAG)
code_variable = re.compile(r"\$_(?:post|get|env|request|server|cookie|session|files|phplib)\[|globals\[|\${", FLAG)
code_func = re.compile(r"(?:\brand|base64_decode|base64_encode|echo|die|print|echo|fopen|fputs|phpinfo|system|passthru|popen|exec|proc_open|exit|\bempty|response\.write)\(|data\[caid\]=",FLAG)
code_file = re.compile(r"(?:ftp_fput|ftp_nb_fput|fopen|ftp_fget|fgets|gzcompress|gzopen|bzopen|gzencode|fwrite|call_user_func|readgzfile|fread|ftp_get|scandir|gzwrite|readdir|session_start|readfile|fscanf|ftp_nb_fget|gzread|ftp_nb_get)\(",FLAG)
code_java = re.compile(r"java\.(?:lang|util|io)\.|xwork\.methodaccessor\.denymethodexecution|auto_(?:pre|ap)pend_file|com\.opensymphony\.xwork2\.dispatcher\.httpservletre(?:quest|sponse)|allowstaticmethodaccess|jboss\.admin",FLAG)
code_spec = re.compile(r"arrs[12]\[\d*?\].*arrs[12]\[\d*?\]",FLAG)


xss_func = re.compile(r"(?:alert|comfirm|indexof|function)\b\s*?\(", FLAG)
xss_left= re.compile(r"\<(?:script|style|[i]?frame|meta|base|layer|input|img|link|embed|applet|object|p\b|h4|ul|form|query|font|span|div|td|a|li)",FLAG)
xss_right = re.compile(r"(?:script|span|[i]?frame|form|div|img|/object|style|\ba|li|tr)>")
xss_keyword = re.compile(r"\bjavascript:|\blocation\.href",FLAG)
xss_others = re.compile(r"[^&]\b(?:onerror|onclick|onload|onmouseover)\s*=|\bdocument\b\s*\.\s*\b(?:cookie|open|domain|close)\b")


#DDOS
ddos_ip_1 = re.compile(r"(http|host|ip)=(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})?",FLAG)
ddos_ip_2 = re.compile(r"time=\d+",FLAG)
ddos_ip_3 = re.compile(r"(exit|port)=\d+",FLAG)

ddos_keyword= re.compile(r"rat=are",FLAG)


#XFILE
xfile_apache = re.compile(r"[^=]\b(?:htaccess|htpasswd|htgroup|httpd)$",FLAG)
xfile_config = re.compile(r"\b(?:httpd|web)\.conf\b|\b(?:win|boot)\.ini\b|\b(?:server_sync|bom)\.php\b|\.config$",FLAG)
xfile_sensitive = re.compile(r"\.(?:mdb|sql|log|svn|inc|myd)(?!\.)\b",FLAG)
xfile_script = re.compile(r"\.(?:asa|asc|asax|xfile|cer|php[1-5])\b",FLAG)
xfile_byte = re.compile(r"(?:cmd|net|net1|ftp|telnet|nmap|nc)\.exe\b(?!.html)",FLAG)
xfile_backup = re.compile(r"\.config\.rar|\.(?:backup|bak)",FLAG)
xfile_protocol = re.compile(r"\bdata:|\bc:/|\bfile:",FLAG)


#LRFI

lrfi_remote = re.compile(r"http://.+\.txt",FLAG)
lrfi_sys_file = re.compile(r"etc/(?:passwd|shadow|motd|group|hosts|rc\.d)|/proc/self/environ",FLAG)
lrfi_sys_hardware = re.compile(r"proc/(?:self/envirion|cmdline|cpuinfo|mounts|mdstat|partitions|version_signature|uptime)",FLAG)
lrfi_web_file = re.compile(r"etc/(?:httpd|phpmyadmin|mysql|php4|php5|apache)",FLAG)
lrfi_backup = re.compile(r"\bvar/(?:log|backups|mail|www)",FLAG)
lrfi_route = re.compile(r"\./|\.\\|\\\.|/\.",FLAG)


# CMS
#cms_dede = re.compile(r"""m=search&c=index&a=public_get_suggest_keyword|&typeArr\[|arrs1\[\d*?\].*arrs2\[\d*?\]|arrs2\[\d*?\].*arrs1\[\d*?\]""", FLAG)
#cms_thinksns = re.compile(r"\bFileName=.*\.(?:php[3-5s]?|phtml|php\.bak|as[apc]x?|cer)\b", FLAG)
#cms_thinksns_1 = re.compile(r"\bact=capture\b",FLAG)
#cms_thinksns_2 = re.compile(r"\bapp=public\b",FLAG)
#cms_qibo = re.compile(r"\bfujsarticle\.php\?.*type=like.*Filename=|\bfujsarticle\.php\?.*Filename=.*type=like|\bjf\.php\?.*dbhost", FLAG)
#cms_kesion = re.compile(r"\bPhotoVote.asp\b\?.*LocalFileName=|\.aspx?\b\?.*LocalFileName=", FLAG)
#cms_lxblog = re.compile(r"\bajaxadmin.php\b\?.*action=upload.*uid=^\w+$|\bajaxadmin.php\b\?.*uid=^\w+$.*action=upload",FLAG)  #request is post 

# SCANNER

scanner_tools = re.compile(r"(?:alibaba\.security\.heimdall|netsparker|ineturl|hydra|webravor|sharingan|pois0n|nikto|nessus|paros|w3af|fimap\.googlecode\.com|arachni|whatweb|dirbuster|msf|synapse|xscaner|api\.scanv\.com|aiscan|apache-httpclient)",FLAG)
scanner_special = re.compile(r"the_file_that_should_never_exist_on_server|injected_by_wvs|version\:3\.0",FLAG)
scanner_keyword = re.compile(r"winhttp\.winhttprequest\.5|microsoft url control",FLAG)
scanner_code = re.compile(r"(?:wget|java|python|ruby|perl|pycurl)",FLAG)
scanner_ua = re.compile(r"5\.0 sf|[\x22\x27]|^ie|^-$|\(compatible\w*\)|^mozilla/(?:[^45]|5\.0(?:$| \(\)))|^mazila|mozilla\/4\.0 \(?:compatib1e; msie 6\.1; windows nt\).*\*/\*|\(compatible; msie 6\.0; windows nt 5\.0; \.net clr 1\.1\.4322\)|\(compatible; msie 6\.1; windows nt\)|\(compatible; msie 5\.00; windows 98\)|\(compatible; msie 6\.0; windows nt 5\.2\)",FLAG)



#WEBSHELL
webshell_jsp = re.compile(r"fsofileexplorer|action=show1file|\.as[ap]\?.*\baction\s*=\s*show1file\b.*\bfolderpath\b|\.jsp\?.*?\bo=vlogin\b|\.jsp\?.*?action=[a-za-z](?:&command=[a-z]+)?$|\.jsp\?.*?action=(?:filesystem|database|about|exit|command)|\.jsp\?.*?sort=1.*(?:down)?file=|\.jsp\?.*?\bfolderpath\b|\.jsp\?.*?sort=1.*dir=",FLAG)
webshell_php = re.compile(r"(?:^|\s)[a-z]{20}=[a-z]{40}(?:$|;)|(?i)(?:admin_(?:spider|b4che10r|silic)pass|aspxspy|b374k|loginpass)\b",FLAG)
webshell_aspx = re.compile(r"aspxspy",FLAG)
webshell_filename = re.compile(r"\b(?:[89]0sec1?|ad_plus_js|aik|;a|av|bakup|ces|checkinq|dedevoteinc|e7xue|flenk|flink_del|fszo|fuc[ck]|hongfeng|infor|indray|list\.inc|long|mb|moon|my[bc]ak|mycool|royal|safe|select_config|sfmb|shv|slhack|var|wisdom|xuwn|zappkey&|zdqd|zhb|c99|r57|4dmin|hehe|lndex)\.php",FLAG)



