#!/usr/bin/env python
#coding=utf-8
import time
import MySQLdb
import pymssql
import re
import sys
from sec import offline_filter
import os
#for line in open('log.config','r'):
	#line=line.strip()
	#print line
	#server_type=line.split(':')[0]
	#log_path=line.split(':')[1]
	#log_name=line.split(':')[2]
	#print server_type
	#web_log(server_type,log_path,log_name)


#web日志取出和过滤
def web_log(server_type,log_path,log_name):
	conn=MySQLdb.connect(host="localhost",user="root",passwd="a123456",db="dawn_guard_log",charset="utf8")
	cursor = conn.cursor()
	if server_type=='iis6':
		if log_name=='Default': 
		#print 'ex'+time.strftime('%C%m%d')
			iis6_log_name='ex'+time.strftime('%g%m%d')+'.log'
			for line in open(log_path+'/'+iis6_log_name,'r'):
				line=line.strip()
				if '#' not in line:
					log_date=int(time.strftime('%g%m%d'))
					#print line
					#print type(log_date)
					#print line.split[' '][3]
					#hehe=line.split[' ']
					#print hehe[0]
					server_ip=line.split(' ')[3]
					req_method=line.split(' ')[4]
					if line.split(' ')[6] != '-':
						req_uri=line.split(' ')[5]+'?'+line.split(' ')[6]
					else:
						req_uri=line.split(' ')[5]
					client_ip=line.split(' ')[10]
					user_agent=line.split(' ')[11]
					resp_code=line.split(' ')[12]
					attack_type=offline_filter(req_uri,user_agent)
					#sip=line.split[' '].[3]
					conn.commit()
					sql = "insert into iis6(log_date,server_ip,req_method,req_uri,client_ip,user_agent,resp_code,attack_type) values(%s,%s,%s,%s,%s,%s,%s,%s)"
					param = (log_date,server_ip,req_method,req_uri,client_ip,user_agent,resp_code)
					response = cursor.execute(sql,param)
					#print response
	else if server_type=='ngnix':
		if log_name=='Default':
			ngnix_log_name='access.log'
			for line in open(log_path+'/'+ngnix_log_name,'r'):
				line=line.strip()
				log_date=int(time.strftime('%g%m%d'))
				req_head=line.split(' ')[4].replace('"','')
				req_method=req_head.split(' ')[0]
				req_uri=req_head.split(' ')[1]
				client_ip=line.split(' ')[0]
				resp_code=line.split(' ')[5]
				referer=line.split(' ')[7].replace('"','')
				user_agent=line.split(' ')[8].replace('"','')
				offline_filter(req_uri,user_agent)
				attack_type=offline_filter(req_uri,user_agent)
				conn.commit()
				sql = "insert into ngnix(log_date,req_method,req_uri,referer,client_ip,user_agent,resp_code,attack_type) values(%s,%s,%s,%s,%s,%s,%s,%s)"
				param = (log_date,req_method,req_uri,referer,client_ip,user_agent,resp_code)
				response = cursor.execute(sql,param)
				#print response
				
	else if server_type=='apache':
		if log_name=='Default':
			apache_log_name='access_log'
			for line in open(log_path+'/'+apache_log_name,'r'):
				line=line.strip()
				log_date=int(time.strftime('%g%m%d'))
				req_head=line.split(' ')[4].replace('"','')
				req_method=req_head.split(' ')[0]
				req_uri=req_head.split(' ')[1]
				client_ip=line.split(' ')[0]
				resp_code=line.split(' ')[5]
				referer=line.split(' ')[7].replace('"','')
				user_agent=line.split(' ')[8].replace('"','')
				offline_filter(req_uri,user_agent)
				conn.commit()
				sql = "insert into apache(log_date,req_method,req_uri,referer,client_ip,user_agent,resp_code,attack_type) values(%s,%s,%s,%s,%s,%s,%s,%s)"
				param = (log_date,req_method,req_uri,referer,client_ip,user_agent,resp_code)
				response = cursor.execute(sql,param)
				#print response
	
	else if server_type=='tomcat':
		if log_name=='Default':
			tomcat_log_name='localhost_access_log.'+time.strftime('%Y-%m-%d')+'.txt'
			for line in open(log_path+'/'+tomcat_log_name,'r'):
				line=line.strip()
				log_date=int(time.strftime('%g%m%d'))
				req_head=line.split(' ')[4].replace('"','')
				req_method=req_head.split(' ')[0]
				req_uri=req_head.split(' ')[1]
				client_ip=line.split(' ')[0]
				resp_code=line.split(' ')[5]
				#referer=line.split(' ')[7].replace('"','')
				#user_agent=line.split(' ')[8].replace('"','')
				offline_filter(req_uri,user_agent)
				conn.commit()
				sql = "insert into tomcat(log_date,req_method,req_uri,client_ip,resp_code,attack_type) values(%s,%s,%s,%s,%s,%s)"
				param = (log_date,req_method,req_uri,client_ip,resp_code)
				response = cursor.execute(sql,param)
				#print response
	conn.close()


#sql语句过滤
def sql_log():
	if server_type=='mysql':
		if log_path=='Default':
			conn=MySQLdb.connect(host="localhost",user="root",passwd="a123456",db="mysql",charset="utf8")
			cursor = conn.cursor()
			conn.commit()
			response = cursor.execute("insert into dawn_guard_log.mysql_seclog select A.event_time,A.user_host,A.argument from mysql.general_log A,dawn_guard_log.mysql_rules B where instr(A.argument,B.rules)>0 or instr(B.rules,A.argument)>0")
			
	else if server_type=='mssql':
		if log_path=='Default':
			#conn=pymssql.connect(host='127.0.0.1',database='master',user='sa',password='***' #SQL SERVER认证
			conn=pymssql.connect(host="127.0.0.1",database="master",trusted=True)#Windows认证
			cursor=conn.cursor()
			response = cursor.execute('insert into dawn_guard_log.mssql_seclog select A.EndTime,A.DatabaseUserName,A.TextData from fn_trace_gettable(N"C:\test\LongRunningQueries.trc",DEFAULT) A,dawn_guard_log.mssql_rules B where charindex(A.argument,B.rules)>0 or charindex(B.rules,A.argument)>0')
			
def server_log():
	if server_type=='windows':
		f=open('tmp.log','w+')
		for line in open('c:\windows\syssec.log'):
			if 'date' in line:
				line=line.strip()
				pattern=re.compile(r'\d+-\d+-\d+')
				match=pattern.search(line)
				if match != None:
					#print match.group(0)
					f.write(match.group(0))

			elif 'time' in line:
				line=line.strip()
				pattern=re.compile(r'\d+:\d+')
				match=pattern.search(line)
				if match != None:
					#print match.group(0)
					f.write(match.group(0))

			elif 'user' in line:
				line=line.strip()
				print line[5:]
				f.write(line[5:])
			elif 'ip' in line:
				line=line.strip()
				pattern=re.compile(r'\d+\.\d+\.\d+\.\d+:3389')
				match=pattern.search(line)
				if match != None:
					#print match.group(0)[0:-5]
					f.writeline(match.group(0)[0:-5])
#考虑多个列，记得最后调整writeline的位置


	elif server_type=='linux':
		os.system("last | awk '$3~/[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/{print $1,$3,$5'-'$6,$7}'|head -20 >tmp.log")
		#root :0.0 Apr-24 01:12





if __name__ == "__main__":
	for line in open('log.config','r'):
		line=line.strip()
		#print line
		server_type=line.split(':')[0]
		log_path=line.split(':')[1]
		log_name=line.split(':')[2]
		#print server_type
		web_log(server_type,log_path,log_name)
		sql_log(server_type,log_path)
		server_log(server_type)
