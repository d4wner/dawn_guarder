#!/usr/bin/env python
#-*- coding:utf-8 -*-

import sys
import time
import urlparse
import urllib2
import os.path
import vcl

def check_attack(req_uri, user_agent):
	"""攻击类型进行分析
	"""
	req_uri = req_uri.lower()
	req_uri = urllib2.unquote(req_uri)
	user_agent = user_agent.lower()
	#user_agent = user_agent.replace("<SP>", " ")			# 还原日志记录中的空格
                      
	attack = "NONE"
	
	# 排除这样的请求
	if req_uri == "/favicon.ico" or req_uri == "/data.bin":
		return attack
	
	if sql_check(req_uri, user_agent):
		attack = "SQLI"
	elif code_check(req_uri, user_agent):
		attack = "CODE"
	elif xss_check(req_uri, user_agent):
		attack = "XSS"
	elif file_check(req_uri, user_agent):
		attack = "XFILE"				   # 敏感文件探测
	elif lrfi_check(req_uri, user_agent):
		attack = "LRFI"					   # 本地/远程文件包含
	elif scan_check(req_uri, user_agent):
	 	attack = "SCANNER"
	elif webshell_check(req_uri, user_agent):		
		attack = "WEBSHELL"
	elif ddos_check(req_uri, user_agent):		
		attack = "DDOS"
	elif cms_check(req_uri, user_agent):   #常用cms
		attack = "CMS"
	else:
		attack = "NONE"

	return attack

def sql_check(req_uri, user_agent):
	if vcl.sqli_tools.search(user_agent):
		return True
	elif vcl.sqli_blind.search(req_uri) or vcl.sqli_blind.search(user_agent):
		return True
	elif vcl.sqli_mysql.search(req_uri) or vcl.sqli_mysql.search(user_agent):
		return True
	elif vcl.sqli_mssql.search(user_agent) or vcl.sqli_mssql.search(req_uri):
		return True
	elif vcl.sqli_access.search(user_agent) or vcl.sqli_access.search(req_uri):
		return True
	elif vcl.sqli_common.search(user_agent) or vcl.sqli_common.search(req_uri):
		return True

def code_check(req_uri, user_agent):
	if vcl.code_keyword.search(req_uri):
		return True
	elif vcl.code_variable.search(req_uri):
		return True
	elif vcl.code_func.search(req_uri):
		return True
	elif vcl.code_func.search(req_uri):
		return True
	elif vcl.code_file.search(req_uri):
		return True
	elif vcl.code_java.search(req_uri):
		return True
	elif vcl.code_spec.search(req_uri):
		return True


def xss_check(req_uri, user_agent):
	if vcl.xss_func.search(req_uri):
		return True
	elif vcl.xss_left.search(req_uri):
		return True
	elif vcl.xss_right.search(req_uri):
		return True
	if vcl.xss_keyword.search(req_uri):
		return True
	if vcl.xss_others.search(req_uri):
		return True

def ddos_check(req_uri, user_agent):
	if vcl.ddos_ip_1.search(req_uri) and vcl.ddos_ip_2.search(req_uri) and vcl.ddos_ip_3.search(req_uri):
		return True
	elif vcl.ddos_keyword.search(req_uri):
		return True
	
	

def xfile_check(req_uri, user_agent):
	if vcl.xfile_apache.search(req_uri):
		return True
	elif vcl.xfile_config.search(req_uri):
		return True
	elif vcl.xfile_sensitive.search(req_uri):
		return True
	elif vcl.xfile_script.search(req_uri):
		return True
	elif vcl.xfile_byte.search(req_uri):
		return True
	elif vcl.xfile_backup.search(req_uri):
		return True
	elif vcl.xfile_protocol.search(req_uri):
		return True



def lrfi_check(req_uri, user_agent):
	if vcl.lrfi_remote.search(req_uri):
		return True
	elif vcl.lrfi_sys_file.search(req_uri):
		return True
	elif vcl.lrfi_sys_hardware.search(req_uri):
    	return True
	elif vcl.lrfi_web_file.search(req_uri):
		return True
	elif vcl.lrfi_backup.search(req_uri):
    	return True
	elif vcl.lrfi_route.search(req_uri):
		return True

def scan_check(req_uri, user_agent):
	if vcl.scanner_tools.search(user_agent):
		return True
	elif vcl.scanner_special.search(req_uri):
		return True
	elif vcl.scanner_keyword.search(user_agent):
		return True
	elif vcl.scanner_code.search(user_agent):
		return True
	elif vcl.scanner_ua.search(user_agent):
		return True

def webshell_check(req_uri, user_agent):
	if vcl.webshell_jsp.search(req_uri):
		return True
	elif vcl.webshell_filename.search(req_uri):
		return True


def offline_filter():
	"""离线安全过滤脚本
	"""
	for ncsa in sys.stdin:
		ncsa = ncsa.strip()
		try:
			(req_uri, user_agent, # 客户端其它信息
			 ) = ncsa.split()
		except:
			return "NONE"
			continue

		new_attack_type = check_attack(req_uri, user_agent)

		return new_attack_type


	
if __name__ == "__main__":
	offline_filter()
